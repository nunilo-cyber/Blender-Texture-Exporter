bl_info = {
    "name": "Export Textures from Selected Cubes",
    "blender": (3, 0, 0),
    "category": "Object",
}

import bpy
import os

# Utility function to save the image in different formats
def save_image(image, filepath, format):
    if format == 'TGA':
        image.filepath_raw = filepath + ".tga"
        image.file_format = 'TARGA'
    elif format == 'PNG':
        image.filepath_raw = filepath + ".png"
        image.file_format = 'PNG'
    elif format == 'JPG':
        image.filepath_raw = filepath + ".jpg"
        image.file_format = 'JPEG'
    image.save()

# Utility function to generate a .vmt file
def generate_vmt(filepath):
    vmt_content = f"""VertexLitGeneric
{{
    "$basetexture" "{filepath}"
}}"""
    vmt_filepath = filepath + ".vmt"
    with open(vmt_filepath, 'w') as vmt_file:
        vmt_file.write(vmt_content)

class ExportTexturesOperator(bpy.types.Operator):
    bl_idname = "object.export_textures"
    bl_label = "Export Textures from Selected Cubes"
    
    directory: bpy.props.StringProperty(subtype='DIR_PATH')
    
    def execute(self, context):
        selected_objects = [obj for obj in bpy.context.selected_objects if obj.type == 'MESH' and obj.data.name.startswith('Cube')]
        
        if not selected_objects:
            self.report({'WARNING'}, "No cubes selected.")
            return {'CANCELLED'}
        
        output_dir = bpy.path.abspath(self.directory)
        os.makedirs(output_dir, exist_ok=True)
        
        formats = ['TGA', 'PNG', 'JPG']
        
        for obj in selected_objects:
            for mat_slot in obj.material_slots:
                if mat_slot.material and mat_slot.material.use_nodes:
                    for node in mat_slot.material.node_tree.nodes:
                        if node.type == 'TEX_IMAGE':
                            image = node.image
                            for format in formats:
                                filepath = os.path.join(output_dir, f"{obj.name}_{image.name}")
                                save_image(image, filepath, format)
                            
                            # Special handling for .vtf
                            vtf_filepath = os.path.join(output_dir, f"{obj.name}_{image.name}.vtf")
                            image.filepath_raw = vtf_filepath
                            image.file_format = 'HDR'
                            image.save()
                            generate_vmt(vtf_filepath)
        
        self.report({'INFO'}, "Textures exported successfully.")
        return {'FINISHED'}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

def menu_func(self, context):
    self.layout.operator(ExportTexturesOperator.bl_idname)

def register():
    bpy.utils.register_class(ExportTexturesOperator)
    bpy.types.VIEW3D_MT_object.append(menu_func)

def unregister():
    bpy.utils.unregister_class(ExportTexturesOperator)
    bpy.types.VIEW3D_MT_object.remove(menu_func)

if __name__ == "__main__":
    register()
